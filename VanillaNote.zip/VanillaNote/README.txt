--Beginner Sticky Note App--
Reference: https://www.youtube.com/watch?v=Efo7nIUF2JY (dcode)

Hi all, this is my first Sticky Note App. 
To add sticky note, click on + button.
To update sticky note, clck on whitespace after inputting into textarea. 
To delete sticky note, double click on text area.
Console logging included. 