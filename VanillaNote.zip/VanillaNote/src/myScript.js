const notesContainer = document.getElementById("app");
const addNoteButton = notesContainer.querySelector(".add-note");

getNotes().forEach(note =>{
    const noteElement = createNoteElement(note.id, note.content);
    notesContainer.insertBefore(noteElement, addNoteButton); //Insert sticky note before "+"
});

//Retrieve all notes in array
function getNotes(){ 
    return JSON.parse(localStorage.getItem("stickynotes-notes") || "[]"); //Convert JSON string to JS array
    console.log("Sticky notes retrieved!");

}

//Performs addNote() upon clicking of button
addNoteButton.addEventListener("click", () => addNote());


/*
saveNotes(notes) Saves array into local storage
stickynotes-notes -> id
JSON.stringify(notes) -> Converting to JSON
*/

function saveNotes(notes){ 
    localStorage.setItem("stickynotes-notes", JSON.stringify(notes)); 
    console.log("Sticky notes saved to local storage!");

}


//Creates a new HTML element: textarea

function createNoteElement(id, content){
    const element = document.createElement("textarea");
    element.classList.add("note");
    element.value = content;
    element.placeholder = "Write here"; 
    

    element.addEventListener("change", ()=> {
        updateNote(id, element.value); //Updates latest content
        console.log("Sticky Note", id, " updated!");

    });

    element.addEventListener("dblclick", () => {
        const doDelete = confirm("Delete sticky note?"); //Returns T or F

        if (doDelete){ //If true, deletes sticky note
            deleteNote(id, element);
            console.log("Sticky Note", id, " deleted!");
        }
    });

    return element;
}

function addNote(){
    const notes = getNotes();
    const noteObject = {
        id: Math.floor(Math.random()* 100000), //Generate random ID
        content:""
    };

    const noteElement = createNoteElement(noteObject.id, noteObject.content);
    notesContainer.insertBefore(noteElement, addNoteButton);

    notes.push(noteObject); 
    saveNotes(notes); //Saves to local storage 
    console.log("Sticky Note", noteObject.id, " added!");
}

function updateNote(id, newContent){
    const notes = getNotes();
    const targetNote = notes.filter(note => note.id == id)[0]; //Filters the selected note id and returns an array of 1 element

    targetNote.content = newContent;
    saveNotes(notes);
    

}

function deleteNote(id, element){
    const notes = getNotes().filter(note => note.id != id);
    saveNotes(notes);
    notesContainer.removeChild(element);
    
}

